# DEFINIÇÕES DOS UNIVERSOS


# antecedentes, que serão as predições indicando a probabilidade do imóvel ser vendido e o seu valor

temperatura = ctrl.Antecedent(np.arange(0, 40, 1), 'temperatura')

luz = ctrl.Antecedent(np.arange(0, 100, 1), 'luz')


# consequente, que será a qualidade do imóvel

qtdeTuristas = ctrl.Consequent(np.arange(0, 100 , 1), 'qtdeTuristas')

# DEFINIÇÕES DAS FUNÇÕES DE PERTINÊNCIA

# temperatura

temperatura['fria'] = fuzz.trapmf(temperatura.universe, [0, 0, 17, 20])

temperatura['morna'] = fuzz.trapmf(temperatura.universe, [17,20,26,29])

temperatura['quente'] = fuzz.trapmf(temperatura.universe, [26,29,40,40])




# luz

luz['nublado'] = fuzz.trapmf(luz.universe, [0, 0,30,50])

luz['parcialmente ensolarado'] = fuzz.trimf(luz.universe, [30, 50 , 100])

luz['ensolarado'] = fuzz.trimf(luz.universe, [50 , 50, 100])




# qualidade

qtdeTuristas['baixa'] = fuzz.trimf(qtdeTuristas.universe, [0, 0, 50])

qtdeTuristas['media'] = fuzz.trimf(qtdeTuristas.universe, [0, 50, 100])

qtdeTuristas['alta'] = fuzz.trimf(qtdeTuristas.universe, [50, 100,100])



# regra 1 - se probabilidade venda é baixa, então qualidade é ruim

regra1 = ctrl.Rule(temperatura['fria'], qtdeTuristas['baixa'])



# regra 2 - se probabilidade venda é médio ou o preço é médio, então qualidade é mediana

regra2 = ctrl.Rule(temperatura['morna'] | luz['parcialmente ensolarado'], qtdeTuristas['media'])



# regra 3 - se probabilidade venda é alta e o preço é alto, então qualidade é boa

regra3 = ctrl.Rule(temperatura['quente'] & luz['ensolarado'], qtdeTuristas['alta'])



# regra 4 - se probabilidade venda é médio ou o preço é baixo, então qualidade é mediana

regra4 = ctrl.Rule(temperatura['morna'] | luz['nublado'], qtdeTuristas['media'])



# regra 5 - se probabilidade venda é baixa e o preço é alto, então qualidade é mediana

regra5 = ctrl.Rule(temperatura['fria'] & luz['ensolarado'], qtdeTuristas['media'])



imovel_ctrl = ctrl.ControlSystem([regra1, regra2, regra3, regra4, regra5])

engine = ctrl.ControlSystemSimulation(imovel_ctrl)



# passa as predições dos modelos para suas respectivas variáveis de entrada

engine.input['temperatura'] = 30

engine.input['luz'] = 50



# calcula a saída do sistema de controle fuzzy

engine.compute()



# retorna o valor crisp e o gráfico mostrando-o

print(engine.output['qtdeTuristas'])

qtdeTuristas.view(sim=engine)



# VISUALIZAÇÃO DAS FUNÇÕES DE PERTINÊNCIA

# temperatura

temperatura.view()



# luz

luz.view()



# qualidade

qtdeTuristas.view()